const Discord = require('discord.js');
const { Client, DiscordAPIError } = require('discord.js');
const { registerCommands, registerEvents } = require('./utils/registry');
const { MessageButton } = require("discord-buttons");
const { token, prefix } = require('../slappey.json');
const { color } = require('./commands/color.json')
const Nuggies = require('nuggies');


const client = new Client({
  intents: [
    "GUILDS",
    "GUILD_MEMBERS",
    "GUILD_BANS",
    "GUILD_EMOJIS",
    "GUILD_MESSAGE_REACTIONS",
    "GUILD_MESSAGES",
    "GUILD_INVITES"
  ]
});

const DisTube = require('distube');
client.distube = new DisTube(client, { searchSongs: false, emitNewSongOnly: true });


(async () => {
  client.commands = new Map();
  client.events = new Map();
  client.prefix = prefix;
  await registerCommands(client, '../commands');
  await registerEvents(client, '../events');
  await client.login(token);
})();




//Select Menu

client.on('clickMenu', menu => {
  Nuggies.dropclick(client, menu);
});




// Music

client.distube
  .on("playSong", (message, queue, song) => {

    const musicPlayEmbed = new Discord.MessageEmbed()
      .setTitle(`Now playing ${song.name}`)
      .setDescription(`Song Duration: ${song.formattedDuration} \nRequested by: ${song.user}`)
      .setColor(color);

    message.channel.send("", {
      embed: musicPlayEmbed
    })
  })

  .on("addSong", (message, queue, song) => {

    const musicAddSongEmbed = new Discord.MessageEmbed()
      .setTitle(`Added ${song.name} to the queue`)
      .setDescription(`Song Duration: ${song.formattedDuration} \nRequested by: ${song.user}`)
      .setColor(color);

    message.channel.send("", {
      embed: musicAddSongEmbed
    })
  })




// Buttons

client.on('clickButton', async (button) => {
  if (button.id === "yes_button") {
    button.defer()
    button.channel.send(`${button.clicker.user.tag} clicked Yepp button!`)
  }

  if (button.id == "no_button") {
    button.defer()
    button.channel.send(`${button.clicker.user.tag} clicket Nope button!`)
  }
});

client.on('clickButton', async (button) => {
  if (button.id === "tomte") {
    button.defer()
    button.channel.send(`${button.clicker.user.tag} Clicked the Nej du hitta detta :(`)
  }

  if (button.id == "tomte2") {
    button.defer()
    button.channel.send(`${button.clicker.user.tag} Clicked the Nej du hitta det men nej :(`)
  }

});

client.on('clickButton', async (button) => {
  if (button.id === "count.click.button") {
    button.defer()
    button.channel.send(`${button.clicker.user.tag} ${1 + 1}`)
  }
});

client.on('clickButton', async (button, message, client) => { //Remove button for music
  if (button.id === "skip") {

    let queue = await client.DisTube.getQueueSSS(message);
    const DisTube = require('distube')
    if (queue) {
      client.DisTube.skip(message)

      message.channel.send("Skipped")
    } else if (!queue) {
      return
    }
  };
});




// Slash Commands

client.on('ready', async () => {
  console.log('Slash Commands Ready')

  const guildId = '857237381244911636'
  const getApp = (guildId) => {
    const app = client.api.applications(client.user.id)
    if (guildId) {
      app.guilds(guildId)
    }
    return app
  }

  const commands = await getApp(guildId).commands.get()

  // Delete Slash Command: await getApp(guildId).commands('CommandID').delete() // CommandID look in console for command ID on startup

  await getApp(guildId).commands.post({
    data: {
      name: 'ping',
      description: 'A simple ping pong command',
    },
  })

  client.ws.on('INTERACTION_CREATE', async (interaction) => {
    const { name, options } = interaction.data
    const command = name.toLowerCase()

    if (command === 'ping') {
      reply(interaction, 'pong')
    }
  })
})

const reply = (interaction, response) => {
  client.api.interactions(interaction.id, interaction.token).callback.post({
    data: {
      type: 4,
      data: {
        content: response,
      },
    }
  })
}