const BaseEvent = require('../../utils/structures/BaseEvent');

module.exports = class ReadyEvent extends BaseEvent {
  constructor() {
    super('ready');
  }
  async run(client) {
    console.log(client.user.tag + ' has logged in.');

    //Activities
    client.user.setActivity(`Startup | 0.1 BΞTA`, { type: 'PLAYING' })

    const activities = [
      `${client.guilds.cache.size} servers!`,
      `${client.guilds.cache.reduce((a, b) => a + b.memberCount, 0)} users!`,
      `.help | Version 0.1 BΞTA`
    ];

    let i = 0;
    setInterval(() => client.user.setActivity(`${activities[i++ % activities.length]}`, { type: 'WATCHING' }), 15000);
  };
}