const { DiscordAPIError } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const Discord = require('discord.js')
const { color } = require('../color.json');


module.exports = class HelpCommand extends BaseCommand {
  constructor() {
    super('help', 'support', []);
  }

  async run(client, message, args) {

    const embed = new Discord.MessageEmbed()
    .setTitle('Help | Swedish Chef')
    .addField('Commands', 's!cat \ns!play {song name} \ns!skip \ns!stop \ns!ping \ns!uptime \ns!purge \ns!serverinfo')
    .setColor(color)

    message.channel.send(embed);
  }
}