const BaseCommand = require('../../utils/structures/BaseCommand');
const { MessageButton } = require("discord-buttons");
const Discord = require('discord.js');
const { color } = require('../color.json');

module.exports = class InfomsgCommand extends BaseCommand {
  constructor() {
    super('infomsg', 'support', []);

  }

  async run(client, message, args) {
  /*
    const embed = new Discord.MessageEmbed()
    .setTitle("Welcome to Droid's Headquarter")
    .setColor("#2f3136")
    .setDescription("Welcome to Droid's Headquarter and thanks for our choice of joining us! \n We are constantly trying to give you the best experience. \n *Here can you see most of the information you need.* \n \n __**INFORMATION**__")
    .addField("Droid", "Droid is a multipurpose bot that can manage invites, moderate, play music, Tickets and much more! \n *Click on the button Droid Below this message*")
    .addField("Private Bot", "We have a cheap price, while still remaining high quality. \n *Check out the prices in <#741934271127748640>* \n \n **__F.A.Q__** \n ***F**requently **A**sked **Q**uestions*")
    .addField("Why should you buy a custom bot?", "With custom bot you will get the commands and features you need and don't any unnecessary.")
    .addField("What can I get?", "Open a ticket and we can discuss what you want and cost");
    
    
    const invemix = new MessageButton()
    .setStyle("url")
    .setLabel("Emix")
    .setURL("https://discord.com/oauth2/authorize?client_id=802453467674181653&scope=bot&permissions=3418176")

    const invdroid = new MessageButton()
    .setStyle("url")
    .setLabel("Droid")
    .setURL("https://discord.com/oauth2/authorize?client_id=731945423270314068&scope=bot&permissions=8")

    const donate = new MessageButton()
    .setStyle("url")
    .setLabel("Donate")
    .setURL("https://www.buymeacoffee.com/droid")

    const ticket = new MessageButton()
    .setStyle("url")
    .setLabel("Ticket")
    .setURL("https://discord.gg/Vcky3VNSht")

     message.channel.send("", {
       buttons: [invdroid, invemix, ticket, donate],
       embed: embed
     })
*/
  }
}
