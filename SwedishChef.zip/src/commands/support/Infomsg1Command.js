const BaseCommand = require('../../utils/structures/BaseCommand');
const { MessageButton } = require("discord-buttons");
const Discord = require('discord.js');
const { color } = require('../color.json');

module.exports = class Infomsg1Command extends BaseCommand {
  constructor() {
    super('infomsg1', 'support', []);
  }

  async run(client, message, args) {
  
/*    const embed = new Discord.MessageEmbed()
    .setTitle("Welcome to The Swedish Chef Server")
    .setColor(color)
    .setDescription("Food is delicious 🍕")
    .addFeild("What are we about?", "We are a community about discord bot coding and creating/selling custom bots")
    
    const invemix = new MessageButton()
    .setStyle("url")
    .setLabel("Emix")
    .setURL("https://discord.com/oauth2/authorize?client_id=802453467674181653&scope=bot&permissions=3418176")

    const invdroid = new MessageButton()
    .setStyle("url")
    .setLabel("Droid")
    .setURL("https://discord.com/oauth2/authorize?client_id=731945423270314068&scope=bot&permissions=8")

    const donate = new MessageButton()
    .setStyle("url")
    .setLabel("Donate")
    .setURL("https://www.buymeacoffee.com/droid")

    const ticket = new MessageButton()
    .setStyle("url")
    .setLabel("Ticket")
    .setURL("https://discord.gg/Vcky3VNSht")

     message.channel.send("", {
       buttons: [invdroid, invemix, ticket, donate],
       embed: embed
     })
*/
  }
}
