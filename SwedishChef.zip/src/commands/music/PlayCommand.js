const BaseCommand = require('../../utils/structures/BaseCommand');
const distube = require('distube');
const { color } = require('../color.json');

module.exports = class PlayCommand extends BaseCommand {
  constructor() {
    super('play', 'music', []);
  }

  async run(client, message, args) {
    if (!message.member.voice.channel) return message.channel.send('You must be in a voice channel to use this command')
    
    const music = args.join(" ");

    client.distube.play(message, music)
  }
}