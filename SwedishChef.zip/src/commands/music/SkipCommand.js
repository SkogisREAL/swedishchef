const BaseCommand = require('../../utils/structures/BaseCommand');
const distube = require('distube');
const { color } = require('../color.json');
const Discord = require('discord.js');

module.exports = class SkipCommand extends BaseCommand {
  constructor() {
    super('skip', 'music', []);
  }

  async run(client, message, args) {
  if (!message.member.voice.channel) return message.channel.send('You must be in a voice channel to use this command')

 /* await bot.distube.skip(message)
 await message.channel.send("Skipped current song")
 */

 let queue = client.distube.getQueue(message)

 if (queue){
  client.distube.skip(message)

message.channel.send('⏩ **Skipped**');
} else if (!queue) {
    return
}; 

  }
}
 
 
 
 
 
 
 
  /* if (queue){
    client.distube.skip(message)

  message.channel.send("Skipped")
  } else if (!queue) {
      return
  }; 
}}








//Skogis
/*
    if (queue){
      client.distube.skip(message)

    message.channel.send("Skipped")
    } else if (!queue) {
        return
    }; 
*/


//Tomten (Ur funktion)
/*
    let fetched = ops.active.get(message.guild.id);

    if (!fetched) return message.channel.send('There isn\'t any music playing in your vc!');

    if (message.member.voiceChannel  !== message.guild.me.voiceChannel) return message.channel.send('Sorry, your not in the same channel as the bot');

    let userCount = message.member.voiceChannel.members.size;

    let required = math.ceil(userCount/2);

    if (!fetched.queue[0].voteSkips) fetched.queue[0].voteSkips = [];

    if (fetched.queue[0].voteSkips.includes(message.member.id)) return message.channel.send(`Sorry, you alredy voted ${fetched.queue[0].voteSkips.length}/${required} required.`);

    fetched.queue[0].voteSkips.push(message.member.id);

    ops.active.set(message.guild.id, fetched);

    if (fetched.queue[0].voteSkips.length >= required) {

      message.channel.send('Successfully skipped song!');

      return fetched.dispatcher.emit('finish')
    }

    message.channel.send(`Successfully voted to skip! ${fetched.queue[0].voteSkips.length}`);
    */