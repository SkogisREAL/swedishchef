const BaseCommand = require('../../utils/structures/BaseCommand');
const distube = require('distube');
const { color } = require('../color.json');

module.exports = class StopCommand extends BaseCommand {
  constructor() {
    super('stop', 'music', []);
  }

  async run(client, message, args) {
    if (!message.member.voice.channel) return message.channel.send('You must be in a voice channel to use this command')

    let queue = await client.distube.getQueue(message);

    if(queue){
      client.distube.stop(message)

    message.channel.send("Stopped Music")
    } else if (!queue) {
        return
    }; 
  }
}