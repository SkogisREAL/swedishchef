const BaseCommand = require('../../utils/structures/BaseCommand');
const Discord = require('discord.js');
const { color } = require('../color.json');

module.exports = class CatCommand extends BaseCommand {
  constructor() {
    super('cat', 'fun', []);
  }

  run(client, message, args) {

    console.log(process.env.COLOR)

    let max = 100000000000
    let min = 1
    let randNo = Math.round(Math.random() * max + min)

    const emb = new Discord.MessageEmbed()
      .setColor(color)
      .setImage(`https://cataas.com/cat?${randNo}`)
      .setTitle('Random Cat');

    message.channel.send(emb)
  }
}
// Cat Image: https://cataas.com/cat?{randomnummer}
