const BaseCommand = require('../../utils/structures/BaseCommand');
const { MessageButton } = require("discord-buttons");
const Discord = require('discord.js');
const { color } = require('../color.json');

module.exports = class ButtonCountCommand extends BaseCommand {
  constructor() {
    super('buttoncount', 'test', []);
  }

  async run(client, message, args) {
/*
    const embed = new Discord.MessageEmbed()
      .setTitle("The Button")
      .setDescription("")
      .setColor(color);

    const click = new MessageButton()
    .setStyle("2")
    .setLabel("Click")
    .setID("count.click.button")

     message.channel.send("", {
       button: click,
       embed: embed
     })
     */
  }
}
