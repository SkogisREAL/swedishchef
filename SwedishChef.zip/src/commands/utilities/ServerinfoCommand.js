const BaseCommand = require('../../utils/structures/BaseCommand');
const Discord = require("discord.js");
const { color } = require('../color.json');

module.exports = class ServerinfoCommand extends BaseCommand {
  constructor() {
    super('serverinfo', 'utilities', []);
  }

  async run(client, message, args) {
    const { guild } = message
    const { name, region, memberCount, owner, channels } = guild
    const icon = guild.iconURL()

    const emb = new Discord.MessageEmbed()
    .setColor(color)
    .setTitle(`${name}'s Server Info`)
    .setThumbnail(icon)
    .addFields(
    {
      name: 'Owner',    
      value: owner.user.tag,
    },
    {
      name: 'Region',
      value: region,
    },
    {
      name: 'Channel Categories',
      value: memberCount,
    },
    {
      name: 'Members',
      value: memberCount,
    },)

    message.channel.send(emb)
  }
}