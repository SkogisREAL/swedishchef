const { default: discordButtons } = require('discord-buttons');
const BaseCommand = require('../../utils/structures/BaseCommand');
const Discord = require('discord.js')
const { color } = require('../color.json');

module.exports = class PingCommand extends BaseCommand {
  constructor() {
    super('ping', 'utilities', []);
  }

  async run(client, message, args) {
    message.channel.send('Calculating ping...').then((resultMessage) => {
      const ping = resultMessage.createdTimestamp - message.createdTimestamp;

      const emb = new Discord.MessageEmbed()
      .setColor(color)
      .setTitle("Bot's Latency")
      .setDescription(`**Ping:** \`${ping}ms\` \n **API Latency:** \`${client.ws.ping}ms\``);

    //  resultMessage.edit(`Bot latency: ${ping}ms, API Latency: ${client.ws.ping}ms`);
      resultMessage.delete()
      message.channel.send(emb)
    })
  }
}
