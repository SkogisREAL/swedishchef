const { DiscordAPIError } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const Discord = require("discord.js");
const { color } = require('../color.json');

module.exports = class PurgeCommand extends BaseCommand {
  constructor() {
    super('purge', 'utlilities', []);
  }

  run(client, message, args) {
    if (message.member.hasPermission("MANAGE_MESSAGES")) {
     message.channel.messages.fetch().then((results) => {
       message.channel.bulkDelete(results)

       const embed = new Discord.MessageEmbed()
       .setDescription(`<a:trashtemp:743809411193241710> ${message.author.tag} Purged the chat!`)
       .setFooter("Discord limits us to 50 messages per purge")
       .setColor(color);

    message.channel.send(embed)
     })
   }
  }
}