const BaseCommand = require('../../utils/structures/BaseCommand');
const discord = ('discord.js')
const { color } = require('../color.json');

module.exports = class EmbendcommentsCommand extends BaseCommand {
  constructor() {
    super('embedinfo', 'test', []);
  }

  run(client, message, args) {
    /*
    const embed = new discord.MessageEmbed()
    .setColor(color)
    .setTitle("Example Title")
    .setDescription(`Example Description, Your tag: ${message.author}`)


    message.channel.send("", {
      embed: embed
    })
    */
  }
}
//${message.author}