const BaseCommand = require('../../utils/structures/BaseCommand');
const { MessageButton } = require("discord-buttons");
const Discord = require('discord.js');
const { color } = require('../color.json');

module.exports = class TomtetestCommand extends BaseCommand {
  constructor() {
    super('test.jultomten.secret.dont.find.this', 'test', []);
  }

  async run(client, message, args) {
/*
    const embed = new Discord.MessageEmbed()
    .setTitle("Super secret command")
    .setDescription(`<@!530823734496329760>, Say Hi!`)
    .setColor(color);

    const yes = new MessageButton()
    .setStyle("url")
    .setLabel("Nej du hitta detta :(")
    .setURL("https://www.youtube.com/user/PewDiePie");

    const no = new MessageButton()
    .setStyle("url")
    .setLabel("Du hitta det men nej :(")
    .setURL("https://www.youtube.com/channel/UC65sf2iQ6QDR-E3iRFpgGww");

     message.channel.send("", {
       buttons: [yes, no],
       embed: embed
     })
     */
  }
}


