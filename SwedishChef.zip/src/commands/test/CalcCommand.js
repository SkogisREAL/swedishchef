const BaseCommand = require('../../utils/structures/BaseCommand');
const Discord = require('discord.js')
const { Calculator } = require('weky')
const disbut = require('discord-buttons');
const { color } = require('../color.json');


module.exports = class CalcCommand extends BaseCommand {
  constructor() {
    super('calc', 'test', []);
  }

  async run(client, message, args) {
    await Calculator(message)
  }
}