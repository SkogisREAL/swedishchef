const BaseCommand = require('../../utils/structures/BaseCommand');
const Nuggies = require('nuggies');
const Discord = require('discord.js')
const { color } = require('../color.json');

module.exports = class DropdownCommand extends BaseCommand {
  constructor() {
    super('dropdown', 'test', []);
  }

  run(client, message, args) {

    const options = new Nuggies.dropdownroles().addrole({
      label: 'Announcements',
      role: '862703644611706880',
      emoji: '862704943579136061'
    }).addrole({
      label: 'Updates',
      role: '862703798367158272',
      emoji: '862706071046717481'
    }).addrole({
      label: 'Events',
      role: '862703853160759316',
      emoji: '📅'
    }).addrole({
      label: 'Giveaways',
      role: '862703879158235148',
      emoji: '🎉'
    });

    Nuggies.dropdownroles.create({
      message: message,
      role: options,
      content: new Discord.MessageEmbed()
      .setTitle('Click To Get Role!')
      .setDescription('This is ping roles.')
      .setColor(color),
      channelID: message.channel.id
    });

  }
}