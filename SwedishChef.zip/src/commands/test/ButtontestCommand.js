const BaseCommand = require('../../utils/structures/BaseCommand');
const { MessageButton } = require("discord-buttons");
const Discord = require('discord.js');
const { color } = require('../color.json');

module.exports = class ButtontestCommand extends BaseCommand {
  constructor() {
    super('buttontest', 'test', []);
  }

  async run(client, message, args) {

    const embed = new Discord.MessageEmbed()
      .setTitle("Test Embed Sak Thingy")
      .setColor(color);

    const yes = new MessageButton()
    .setStyle("2")
    .setLabel("Yepp")
    .setID("yes_button")

    const no = new MessageButton()
    .setStyle("2")
    .setLabel("Nope")
    .setID("no_button")

     message.channel.send("", {
       buttons: [yes, no],
       embed: embed
     })
  }
}
