const BaseCommand = require('../../utils/structures/BaseCommand');
const { color } = require('../color.json');

module.exports = class VartestCommand extends BaseCommand {
  constructor() {
    super('var.test.dont.find.this', 'test', []);
  }
  
  async run(client, message, args) {
    /*
      let x = ("hola din sås");
      message.channel.send(x)
      */
  } 
}

//var = siffror
//let = går inte att ändra om den blivit declarde 
//ps endast rekommederad för text ^^^
//const = construct, consturerar fast