const BaseCommand = require('../../utils/structures/BaseCommand');
const { color } = require('../color.json');
module.exports = class TicketCommand extends BaseCommand {
  constructor() {
    super('ticket', 'owneronly', []);
  }

  run(client, message, args) {
    
  }
}