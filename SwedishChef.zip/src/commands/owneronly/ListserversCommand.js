const BaseCommand = require('../../utils/structures/BaseCommand');
const { DiscordAPIError } = require('discord.js');
const Discord = require("discord.js");
const { color } = require('../color.json');

module.exports = class ListserversCommand extends BaseCommand {
  constructor() {
    super('listservers', 'botowner', []);
  }

  run(client, message, args) {
    if (message.member.hasPermission("ADMINISTRATOR")) {
    client.guilds.cache.forEach(guild => {
      
      const embed = new Discord.MessageEmbed()
      .setColor(color)
      .setTitle(`Guild: ${guild.name}`)
      .addField(`Basic Info`, `Members: ${guild.memberCount} \n Owner: ${guild.owner}, ${guild.ownerID}`)
      message.channel.send(embed);

    })
   }
  }
}